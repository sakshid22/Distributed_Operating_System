defmodule Proj1 do
  @moduledoc """
    Main module of the application which is used to start the Supervisor.
  """
  @doc """
    Converts arguments to integers and passes them to the Supervisor.
  """
  def start(a,b) do
    n = String.to_integer(a)
    k = String.to_integer(b)
    args = [n,k]
    Proj1.Supervisor.start_link(args)
  end
end


defmodule Proj1.Service do
  @moduledoc """
    It performs the necessary computation and prints the output. Implements Tasks to get concurrency.
  """
  use Task
  @doc """
    Starts a new task.
  """
  def start_link({n,k,t}) do
    Task.start_link(__MODULE__, :init, [{n,k,t}])
  end
  @doc """
    Initializes the variables in a task and starts the main function.
  """
  def init(args) do
    {n,k,t} = args
    n = if(!(n==0)) do
      (n-1) * t + 1
    end
    sum = 0
    main(n,k,t,sum)

    {:ok, args}
  end
  @doc """
    main functions are used to get the sum of a series and checks whether the sum is a perfect square. After that it prints the output.
    The first two main functions are just end conditions for recursion.
  """
  def main(_,_,0,_) do
    {:ok}
  end

  def main(0,_,_,_) do
    {:ok}
  end

  def main(n,k,t,sum) do
    sum = compute(n,k,sum)
    sq = :math.sqrt(sum)
    s = Kernel.trunc(sq)
    if(sq == s) do
      IO.puts "#{n}"
    end
    main(n+1 , k, t-1, sum)
  end

  @doc """
    Compute functions are used to calculate the sum of the series.
    The first two compute functions will be used to calculate the first series sum in one task.
    The third compute function will be used for all subsequent series.
  """
  def compute(n, 1, _) do
    n * n
  end

  def compute(n, k, 0) do
    n * n + compute(n+1, k-1, 0)
  end

  def compute(n, k, sum) do
    sum - ((n-1) * (n-1)) + ((n+k-1) * (n+k-1))
  end

end

defmodule Proj1.Supervisor do
  @moduledoc """
    This module defines the Supervisor and is responsible to start all the workers. Each worker is responsible to perform 2500 series computations
    and check whether it is a perfect square or not.
  """
  use Supervisor

  @doc """
    It starts the Supervisor.
  """
  def start_link(args) do
    Supervisor.start_link(__MODULE__, [args])
  end

  @doc """
    It checks how many workers are needed and then initializes them all with the proper arguments. The supervise function then starts all the
    workers which perform concurrent operations.
  """
  def init(args) do
    [[n,k]] = args
    batch = 2500
    [n,t,r] = cond do
      rem(n, batch) == 0 ->
        [div(n,batch), batch, 0]
      true ->
        [div(n,batch), batch, rem(n,batch)]
      end
    children = if(!(n==0)) do
      remainder(n*batch, k, r)
      Enum.map(1..n, fn(num) -> worker(Proj1.Service, [{num,k,t}], [id: "#{num}", restart: :transient]) end)
    else
      Enum.map(1..1,fn(num) -> worker(Proj1.Service, [{num,k,r}], [id: "rem", restart: :transient]) end)
    end
    supervise(children, [strategy: :one_for_one])
  end

  @doc """
    This function is used to compute for the remaining series when n is not exactly divisible by 2500.
  """
  def remainder(n,k,r) do
    Proj1.Service.main(n,k,r,0)
  end
end
