defmodule Proj1Test do
  use ExUnit.Case
  doctest Proj1

  test "greets the world" do
    assert Proj1.hello() == :world
  end
end
